<?php include "includes/header.php"?>

    <p>Please fill out the form below with any pertinent information you would like to inquire about! Thanks!</p>

    <?php include "includes/multiple.php"?>

    </section>
    <!-- END LEFT COL -->

    <!-- START RIGHT COL -->
    <aside>
     <h3>Additional Resources</h3>
        <ul>
            <li><a href="https://www.w3schools.com/">W3Schools</a>, the best documentation!</li>
            <li><a href="https://uxplanet.org/5-free-quick-wireframe-tools-for-ui-ux-designers-in-2017-189e6a594fda">5 Great Wireframe Tools for Designers!</a></li>
            <li><a href="https://survicate.com/website-survey/questions/">20 Great Questions for a Client Survey!</a></li>
        </ul>
    </aside>
    <!-- END RIGHT COL -->

<?php include "includes/footer.php"?>