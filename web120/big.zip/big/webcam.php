<?php include "includes/header.php"?>

    <p>Chill Beats to Study To</p>

    <div class="embed-container">
        <iframe src='https://www.youtube.com/embed/FlKlmgksvgQ?rel=0&autoplay=1' allowfullscreen></iframe>
    </div>

    </section>
    <!-- END LEFT COL -->

    <!-- START RIGHT COL -->
    <aside>
     <h3>SR 99 &amp; S Atlantic St Traffic Cam</h3>
    <div class="embed-container dot">
        <iframe src="webcam.html"></iframe>
    </div>
    </aside>
    <!-- END RIGHT COL -->

<?php include "includes/footer.php"?>