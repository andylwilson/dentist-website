<?php include "includes/header.php"?>

    <div class="embed-container">
        <iframe src='https://www.youtube.com/embed/Onf_SUv61i4' allowfullscreen></iframe>
    </div>

    </section>
    <!-- END LEFT COL -->

    <!-- START RIGHT COL -->
    <aside>
     <h3>Additional Resources</h3>
        <ul>
            <li><a href="https://fitsmallbusiness.com/what-is-a-content-management-system-cms/">What Is a CMS? All You Need to Know About Content Management Systems</a></li>
            <li><a href="https://financesonline.com/top-15-content-management-software-systems-business/">Top 15 Content Management Software Systems</a></li>
            <li><a href="https://code.tutsplus.com/articles/top-10-most-usable-content-management-systems--net-6493">Top 10 Most Usable Content Management Systems</a></li>
        
        </ul>
    </aside>
    <!-- END RIGHT COL -->

<?php include "includes/footer.php"?>