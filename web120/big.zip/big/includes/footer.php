<!--footer.php include starts here-->
<!-- START Footer -->
<footer>
  <p><small>&copy; <?=date('Y')?> by <a href="contactme.php">Andy Wilson</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer">Valid CSS</a></small></p>
</footer>
<!-- END Footer --> 

</div>
<!-- END WRAPPER -->

</body>
</html>