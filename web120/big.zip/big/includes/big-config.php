<?php
/*
big-config.php This page is used to store all of our WEB120 configuration information
*/

// this helps eliminate PHP date errors
date_default_timezone_set('America/Los Angeles');

// this is a constant that allows a page to know its own url/name
define('THIS_PAGE',basename($_SERVER['PHP_SELF']));

//Here are the keys for the server: 
$siteKey = "6Lc95FQUAAAAAG0vx7lCe6aw2E-OwehOhhsowTPA";
$secretKey = "6Lc95FQUAAAAAHwFR5_gHYIsX90n9wWCZk_Thps_";

switch(THIS_PAGE){

    case 'index.php':
        $title = "Andy Wilson: Web Dev Examples";
        $logo = 'fa-compass';
        $PageID = 'Future Client Form';        
    break;
        
    case 'flexbox.php':
        $title = "Andy Wilson's Flexbox Research";
        $logo = 'fa-th-large';
        $PageID = 'Flexbox Research';        
    break;

    case 'galleries.php':
        $title = "Andy Wilson's Galleries Research";
        $logo = 'fa-file-image-o';
        $PageID = 'Galleries Research';        
    break;
        
    case 'map.php':
        $title = "Andy Wilson's Google Map";
        $logo = 'fa-map-o';
        $PageID = 'Where in the world is Andy?';        
    break;

    case 'youtube.php':
        $title = "Andy Wilson's Wordpress VS Joomla";
        $logo = 'fa-youtube';
        $PageID = 'Wordpress VS Joomla';        
    break;

    case 'calendar.php':
        $title = "Andy Wilson's Event Calendar";
        $logo = 'fa-calendar';
        $PageID = "Andy's event Calendar";        
    break;
        
    case 'parallax.php':
        $title = "Andy Wilson's Parallax Research";
        $logo = 'fa-window-restore';
        $PageID = 'Parallax Research';        
    break;

    case 'shoppingcarts.php':
        $title = "Andy Wilson's Shopping Cart Research";
        $logo = 'fa-shopping-cart';
        $PageID = 'Shopping Cart Research';        
    break;
        
    case 'siteapp.php':
        $title = "Andy Wilson's Responsive Website VS Native Mobile App";
        $logo = 'fa-mobile';
        $PageID = 'Responsive Website VS Native Mobile App Research';        
    break;
        
    case 'webcam.php':
        $title = "Andy Wilson's Two Examples of Web Cams";
        $logo = 'fa-video-camera';
        $PageID = 'Two examples of web cams';        
    break;
        
    default:
        $title = THIS_PAGE;
        $logo = 'fa-home';
        $PageID = '';
    break;
        
}

?>